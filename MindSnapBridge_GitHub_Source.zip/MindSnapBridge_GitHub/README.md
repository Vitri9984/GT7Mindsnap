# Mind Snap Bridge — GitHub APK build for realme GT 7

This is an experimental, non-root Android workaround. It is **not** a port of the GT 8 Pro's privileged SystemUI integration.

## Build the APK using GitHub (phone-only workflow)

1. Create a GitHub account if needed, then create a **new public repository** named `MindSnapBridge-GT7`.
2. On GitHub mobile/web, upload the contents of this folder to the repository root. Ensure `.github/workflows/build-apk.yml` is included (GitHub's web uploader may hide dot-folders; if so, create the workflow file using **Add file → Create new file** and use the exact path `.github/workflows/build-apk.yml`).
3. Open the repository → **Actions** → **Build Mind Snap Bridge APK** → **Run workflow**.
4. Wait for the workflow to finish successfully. Open the completed run, scroll to **Artifacts**, and download `MindSnapBridge-GT7-debug-apk`.
5. Extract the ZIP artifact on the phone. Install `app-debug.apk`; allow installation from the browser/files app if Android asks.

A push to `main` also triggers a build automatically.

## Setup

1. Open Mind Snap Bridge and tap **Enable capture service**.
2. In Android Accessibility settings, enable **Mind Snap Bridge capture and gesture**.
3. Return to the app and tap **Turn gesture zone ON / OFF** until the zone is ON.
4. Place three fingers inside the narrow blue strip at the right edge and swipe upward. It captures the display, saves a PNG under `Pictures/MindSnapBridge`, and attempts to open Mind Space (`com.oplus.aimemory`) with the image.
5. If direct handoff is rejected, the capture remains saved. Use the Quick Settings **Mind Snap** tile as a fallback after adding it from the tile editor.

## Limitations / safety

- A third-party app cannot register the GT 8 Pro's privileged global SystemUI gesture. This implementation uses a narrow accessibility overlay; it only detects a three-finger swipe that starts inside that strip. The strip intercepts touches in its area.
- Mind Space's package is targeted, but its exact internal import contract is undocumented. If that activity rejects external images, the file is saved but may not be auto-imported.
- Protected/DRM screens may block screenshots. The accessibility service does not inspect screen text or upload captures itself.
- This debug APK is not Play-Store signed. Install only the APK built from this repository that you control.
