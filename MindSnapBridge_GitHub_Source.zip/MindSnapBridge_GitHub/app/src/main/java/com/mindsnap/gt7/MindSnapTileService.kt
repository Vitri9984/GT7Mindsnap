package com.mindsnap.gt7

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class MindSnapTileService : TileService() {
    override fun onClick() { super.onClick(); MindSnapAccessibilityService.instance?.captureAndShare(); qsTile?.state = Tile.STATE_INACTIVE; qsTile?.updateTile() }
}
