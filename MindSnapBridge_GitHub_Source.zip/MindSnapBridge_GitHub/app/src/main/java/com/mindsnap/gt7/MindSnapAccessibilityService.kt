package com.mindsnap.gt7

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.media.Image
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView

class MindSnapAccessibilityService : AccessibilityService() {
    private var wm: WindowManager? = null
    private var zone: View? = null
    private val handler = Handler(Looper.getMainLooper())
    private var startY = 0f
    private var fingers = 0
    companion object { @Volatile var instance: MindSnapAccessibilityService? = null; @Volatile var refreshZone = false }
    override fun onServiceConnected() { super.onServiceConnected(); instance = this; wm = getSystemService(WINDOW_SERVICE) as WindowManager; updateZone() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { if (refreshZone) { refreshZone = false; updateZone() } }
    override fun onInterrupt() {}
    override fun onDestroy() { removeZone(); instance = null; super.onDestroy() }
    private fun updateZone() {
        removeZone()
        if (!getSharedPreferences("bridge", MODE_PRIVATE).getBoolean("zone", false)) return
        val v = TextView(this).apply {
            text = "3\nF\n↑"; textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { setColor(0x663B82F6); cornerRadius = 24f; setStroke(2, 0xFF60A5FA.toInt()) }
            setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { fingers = 1; startY = e.rawY }
                    MotionEvent.ACTION_POINTER_DOWN -> fingers = e.pointerCount
                    MotionEvent.ACTION_MOVE -> { fingers = e.pointerCount; if (fingers >= 3 && startY - e.rawY > 70) { fingers = 0; captureAndShare(); true } else true }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> fingers = 0
                }; true
            }
        }
        val params = WindowManager.LayoutParams((42 * resources.displayMetrics.density).toInt(), (150 * resources.displayMetrics.density).toInt(), WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL }
        try { wm?.addView(v, params); zone = v } catch (_: Exception) { }
    }
    private fun removeZone() { try { zone?.let { wm?.removeView(it) } } catch (_: Exception) {}; zone = null }
    fun captureAndShare() {
        if (Build.VERSION.SDK_INT < 30) return
        takeScreenshot(DisplayManager.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                val hardwareBuffer = result.hardwareBuffer
                try {
                    val hardwareBitmap = android.graphics.Bitmap.wrapHardwareBuffer(hardwareBuffer, result.colorSpace) ?: return
                    val bitmap = hardwareBitmap.copy(android.graphics.Bitmap.Config.ARGB_8888, false)
                    hardwareBitmap.recycle()
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "MindSnap_${System.currentTimeMillis()}.png")
                        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/MindSnapBridge")
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    if (uri != null) contentResolver.openOutputStream(uri)?.use { bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
                    bitmap.recycle()
                    if (uri != null) shareToMindSpace(uri)
                } catch (_: Exception) {
                } finally { hardwareBuffer.close() }
            }
            override fun onFailure(errorCode: Int) { }
        })
    }
    private fun shareToMindSpace(uri: Uri) {
        val send = Intent(Intent.ACTION_SEND).apply { type = "image/png"; putExtra(Intent.EXTRA_STREAM, uri); clipData = android.content.ClipData.newUri(contentResolver, "Mind Snap", uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        val targeted = Intent(send).setPackage("com.oplus.aimemory")
        try { targeted.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(targeted) }
        catch (_: Exception) { send.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(Intent.createChooser(send, "Send capture to Mind Space").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
}
