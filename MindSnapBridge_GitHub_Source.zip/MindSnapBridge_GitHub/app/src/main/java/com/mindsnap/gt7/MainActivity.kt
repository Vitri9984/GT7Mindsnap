package com.mindsnap.gt7

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(28, 36, 28, 36) }
        root.addView(TextView(this).apply { text = "Mind Snap Bridge for realme GT 7\n\nEnable the accessibility service, then enable the gesture zone. Three fingers swipe upward inside the narrow right-edge zone to capture."; textSize = 17f })
        root.addView(Button(this).apply { text = "Enable capture service"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        root.addView(Button(this).apply { text = "Turn gesture zone ON / OFF"; setOnClickListener { getSharedPreferences("bridge", MODE_PRIVATE).edit().putBoolean("zone", !getSharedPreferences("bridge", MODE_PRIVATE).getBoolean("zone", false)).apply(); MindSnapAccessibilityService.refreshZone = true; text = if (getSharedPreferences("bridge", MODE_PRIVATE).getBoolean("zone", false)) "Gesture zone is ON" else "Gesture zone is OFF" } })
        root.addView(Button(this).apply { text = "Capture screen now"; setOnClickListener { MindSnapAccessibilityService.instance?.captureAndShare() } })
        root.addView(TextView(this).apply { text = "Note: Android/realme does not let a normal app replace the GT 8 Pro's privileged global gesture. This uses a small touch zone and an accessibility screenshot."; textSize = 13f })
        setContentView(root)
    }
}
